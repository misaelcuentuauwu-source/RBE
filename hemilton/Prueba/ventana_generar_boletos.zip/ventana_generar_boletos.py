# ventana_generar_boletos.py - PARTE 1 CORREGIDA

from datetime import datetime
from PySide6.QtWidgets import (
    QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout,
    QFrame, QScrollArea, QFileDialog, QMessageBox,
    QColorDialog, QButtonGroup, QRadioButton
)
from PySide6.QtCore import Qt, QRect, QPoint, QSize
from PySide6.QtGui import QFont, QPainter, QColor, QPen, QImage, QPixmap
from PySide6.QtPrintSupport import QPrinter
from conexion import crear_conexion


class TicketCanvas(QFrame):
    """Widget que dibuja el boleto personalizado con soporte para imágenes"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(760, 280)
        self.setMaximumSize(760, 280)
        
        # Datos del boleto
        self.numero_boleto = "345345222"
        self.origen = "Tijuana"
        self.destino = "Mexicali"
        self.fecha_salida = "29/11/2025 14:30"
        self.asiento = "12"
        self.pasajero = "Juan Pérez"
        self.precio = "$250.00"
        self.tipo_pasajero = "Regular"
        
        # Colores personalizables
        self.color_primario = QColor("#0074B7")
        self.color_secundario = QColor("#FFFFFF")
        self.color_texto = QColor("#000000")
        self.color_acento = QColor("#E86A1E")
        
        # Sistema de imágenes/logos
        self.imagen_logo = None  # QPixmap del logo personalizado
        self.mostrar_logo = True
        self.posicion_logo = "superior_izquierda"  # opciones: superior_izquierda, superior_derecha, centro
        
        self.setStyleSheet("background: white; border: 2px solid #ccc; border-radius: 8px;")
    
    def set_datos(self, datos):
        """Actualiza los datos del boleto"""
        self.numero_boleto = datos.get('numero_boleto', '')
        self.origen = datos.get('origen', '')
        self.destino = datos.get('destino', '')
        self.fecha_salida = datos.get('fecha_salida', '')
        self.asiento = datos.get('asiento', '')
        self.pasajero = datos.get('pasajero', '')
        self.precio = datos.get('precio', '')
        self.tipo_pasajero = datos.get('tipo_pasajero', '')
        self.update()
    
    def set_colores(self, primario, secundario, texto, acento):
        """Actualiza los colores del boleto"""
        self.color_primario = QColor(primario)
        self.color_secundario = QColor(secundario)
        self.color_texto = QColor(texto)
        self.color_acento = QColor(acento)
        self.update()
    
    def set_logo(self, ruta_imagen):
        """Carga una imagen como logo personalizado"""
        if ruta_imagen:
            self.imagen_logo = QPixmap(ruta_imagen)
            if self.imagen_logo.isNull():
                self.imagen_logo = None
                return False
            self.update()
            return True
        return False
    
    def eliminar_logo(self):
        """Elimina el logo personalizado"""
        self.imagen_logo = None
        self.update()
    
    def set_posicion_logo(self, posicion):
        """Cambia la posición del logo"""
        self.posicion_logo = posicion
        self.update()
    
    def paintEvent(self, event):
        super().paintEvent(event)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        
        w, h = self.width(), self.height()
        margen = 20
        
        # Línea divisoria punteada vertical
        pen = QPen(QColor("#CCCCCC"), 2, Qt.DashLine)
        painter.setPen(pen)
        painter.drawLine(w//2, margen, w//2, h-margen)
        
        # ===== PARTE IZQUIERDA =====
        izq_w = w // 2
        
        # Cabecera
        painter.fillRect(0, 0, izq_w, 80, self.color_primario)
        
        # Logo autobús (solo si no hay logo personalizado en esa posición)
        if not self.imagen_logo or self.posicion_logo != "superior_izquierda":
            painter.setPen(QPen(self.color_secundario, 3))
            painter.setBrush(self.color_secundario)
            bus_x, bus_y = 30, 20
            painter.drawRoundedRect(bus_x, bus_y, 50, 40, 5, 5)
            painter.fillRect(bus_x+10, bus_y+8, 12, 10, self.color_primario)
            painter.fillRect(bus_x+28, bus_y+8, 12, 10, self.color_primario)
        
        # Título
        painter.setPen(self.color_secundario)
        painter.setFont(QFont("Arial", 18, QFont.Bold))
        painter.drawText(QRect(100, 15, 300, 30), Qt.AlignLeft, "RUTAS BAJA EXPRESS")
        
        painter.setFont(QFont("Courier", 12, QFont.Bold))
        painter.drawText(QRect(100, 45, 300, 25), Qt.AlignLeft, "★ RBE ★")
        painter.setFont(QFont("Courier", 14, QFont.Bold))
        painter.drawText(QRect(100, 55, 300, 25), Qt.AlignLeft, self.numero_boleto)
        
        # ===== ORIGEN Y DESTINO CON LÍNEA DECORATIVA CORREGIDA =====
        y_offset = 100
        painter.setPen(self.color_texto)
        
        # Origen
        painter.setFont(QFont("Arial", 11, QFont.Bold))
        painter.drawText(QRect(margen, y_offset, 150, 20), Qt.AlignLeft, "ORIGEN:")
        painter.setFont(QFont("Arial", 16, QFont.Bold))
        painter.drawText(QRect(margen, y_offset+20, 150, 30), Qt.AlignLeft, self.origen)
        
        # Destino
        painter.setFont(QFont("Arial", 11, QFont.Bold))
        painter.drawText(QRect(izq_w-170, y_offset, 150, 20), Qt.AlignRight, "DESTINO:")
        painter.setFont(QFont("Arial", 16, QFont.Bold))
        painter.drawText(QRect(izq_w-170, y_offset+20, 150, 30), Qt.AlignRight, self.destino)
        
        # ===== LÍNEA DECORATIVA CORREGIDA =====
        y_line = y_offset + 30  # Centrada verticalmente con el texto
        
        # Calcular posiciones dinámicamente basadas en el ancho del texto
        fm = painter.fontMetrics()
        ancho_origen = fm.horizontalAdvance(self.origen)
        ancho_destino = fm.horizontalAdvance(self.destino)
        
        # Círculo origen (justo después del texto)
        circulo_origen_x = margen + ancho_origen + 15
        painter.setPen(QPen(self.color_primario, 2))
        painter.setBrush(self.color_primario)
        painter.drawEllipse(circulo_origen_x - 5, y_line - 5, 10, 10)
        
        # Círculo destino (justo antes del texto)
        circulo_destino_x = izq_w - margen - ancho_destino - 15
        painter.setPen(QPen(self.color_acento, 2))
        painter.setBrush(self.color_acento)
        painter.drawEllipse(circulo_destino_x - 5, y_line - 5, 10, 10)
        
        # Línea central con guiones (entre los dos círculos)
        painter.setPen(QPen(self.color_acento, 2, Qt.DashLine))
        linea_inicio = circulo_origen_x + 10
        linea_fin = circulo_destino_x - 10
        painter.drawLine(linea_inicio, y_line, linea_fin, y_line)
        
        y_offset += 70
        
        # Fecha
        painter.setPen(self.color_texto)
        painter.setFont(QFont("Arial", 10, QFont.Bold))
        painter.drawText(QRect(margen, y_offset, 200, 20), Qt.AlignLeft, "FECHA Y HORA:")
        painter.setFont(QFont("Arial", 13))
        painter.drawText(QRect(margen, y_offset+18, 200, 25), Qt.AlignLeft, self.fecha_salida)
        
        y_offset += 50
        
        # Asiento
        painter.setPen(self.color_acento)
        painter.setBrush(self.color_acento)
        painter.drawRoundedRect(margen, y_offset, 100, 45, 8, 8)
        painter.setPen(QColor("white"))
        painter.setFont(QFont("Arial", 10, QFont.Bold))
        painter.drawText(QRect(margen, y_offset+5, 100, 20), Qt.AlignCenter, "ASIENTO")
        painter.setFont(QFont("Arial", 20, QFont.Bold))
        painter.drawText(QRect(margen, y_offset+20, 100, 25), Qt.AlignCenter, self.asiento)
        
        # Precio
        painter.setPen(self.color_primario)
        painter.setBrush(Qt.NoBrush)
        painter.drawRoundedRect(margen+120, y_offset, 120, 45, 8, 8)
        painter.setFont(QFont("Arial", 10, QFont.Bold))
        painter.drawText(QRect(margen+120, y_offset+5, 120, 20), Qt.AlignCenter, "PRECIO")
        painter.setFont(QFont("Arial", 16, QFont.Bold))
        painter.drawText(QRect(margen+120, y_offset+20, 120, 25), Qt.AlignCenter, self.precio)
        
        # ===== PARTE DERECHA (Talón) =====
        der_x = w // 2
        der_w = w // 2
        
        painter.fillRect(der_x, 0, der_w, h, QColor("#F5F5F5"))
        painter.fillRect(der_x, 0, der_w, 80, self.color_primario)
        
        # Logo pequeño
        painter.setPen(QPen(self.color_secundario, 2))
        painter.setBrush(self.color_secundario)
        bus_x2, bus_y2 = der_x + 20, 25
        painter.drawRoundedRect(bus_x2, bus_y2, 40, 30, 4, 4)
        painter.fillRect(bus_x2+8, bus_y2+6, 10, 8, self.color_primario)
        painter.fillRect(bus_x2+22, bus_y2+6, 10, 8, self.color_primario)
        
        painter.setPen(self.color_secundario)
        painter.setFont(QFont("Courier", 10, QFont.Bold))
        painter.drawText(QRect(der_x+70, 20, 200, 20), Qt.AlignLeft, "★ RBE ★")
        painter.setFont(QFont("Courier", 12, QFont.Bold))
        painter.drawText(QRect(der_x+70, 40, 200, 25), Qt.AlignLeft, self.numero_boleto)
        
        # Info talón
        y_talon = 100
        painter.setPen(self.color_texto)
        
        painter.setFont(QFont("Arial", 9, QFont.Bold))
        painter.drawText(QRect(der_x+15, y_talon, der_w-30, 20), Qt.AlignLeft, "PASAJERO:")
        painter.setFont(QFont("Arial", 11))
        painter.drawText(QRect(der_x+15, y_talon+18, der_w-30, 25), Qt.AlignLeft, self.pasajero)
        
        y_talon += 50
        
        painter.setFont(QFont("Arial", 9, QFont.Bold))
        painter.drawText(QRect(der_x+15, y_talon, der_w-30, 20), Qt.AlignLeft, "TIPO:")
        painter.setFont(QFont("Arial", 11))
        painter.drawText(QRect(der_x+15, y_talon+18, der_w-30, 25), Qt.AlignLeft, self.tipo_pasajero)
        
        y_talon += 50
        
        painter.setFont(QFont("Arial", 13, QFont.Bold))
        painter.setPen(self.color_acento)
        painter.drawText(QRect(der_x+15, y_talon, der_w-30, 30), Qt.AlignCenter, 
                        f"{self.origen} → {self.destino}")
        
        y_talon += 40
        
        painter.setPen(self.color_primario)
        painter.setBrush(self.color_primario)
        painter.drawRoundedRect(der_x+30, y_talon, 80, 35, 6, 6)
        painter.setPen(QColor("white"))
        painter.setFont(QFont("Arial", 9, QFont.Bold))
        painter.drawText(QRect(der_x+30, y_talon+3, 80, 15), Qt.AlignCenter, "ASIENTO")
        painter.setFont(QFont("Arial", 16, QFont.Bold))
        painter.drawText(QRect(der_x+30, y_talon+15, 80, 20), Qt.AlignCenter, self.asiento)
        
        # Código de barras simulado
        painter.setPen(self.color_texto)
        for i in range(30):
            x = der_x + 130 + i*3
            altura = 20 if i % 3 == 0 else 30
            painter.drawLine(x, y_talon+5, x, y_talon+altura)
        
        # ===== DIBUJAR LOGO PERSONALIZADO (si existe) =====
        if self.imagen_logo and self.mostrar_logo:
            self._dibujar_logo_personalizado(painter, w, h)
        
        painter.end()
    
    def _dibujar_logo_personalizado(self, painter, w, h):
        """Dibuja el logo personalizado en la posición seleccionada"""
        logo_size = 60  # Tamaño del logo
        margen_logo = 15
        
        # Escalar logo manteniendo aspecto
        logo_escalado = self.imagen_logo.scaled(
            logo_size, logo_size, 
            Qt.KeepAspectRatio, 
            Qt.SmoothTransformation
        )
        
        # Calcular posición según configuración
        if self.posicion_logo == "superior_izquierda":
            x = margen_logo
            y = 15
        elif self.posicion_logo == "superior_derecha":
            x = (w // 2) - logo_size - margen_logo
            y = 15
        elif self.posicion_logo == "centro":
            x = (w // 4) - (logo_size // 2)
            y = (h // 2) - (logo_size // 2)
        else:
            x = margen_logo
            y = 15
        
        # Dibujar fondo blanco para el logo (opcional)
        painter.fillRect(x-5, y-5, logo_size+10, logo_size+10, QColor(255, 255, 255, 200))
        
        # Dibujar logo
        painter.drawPixmap(x, y, logo_escalado)
    
    def exportar_imagen(self):
        """Exporta el boleto como imagen"""
        image = QImage(self.size(), QImage.Format_ARGB32)
        image.fill(Qt.white)
        
        painter = QPainter(image)
        self.render(painter, QPoint(0, 0))
        painter.end()
        
        return image
    
class VentanaGenerarBoletos(QWidget):
    def __init__(self, pasajeros_info=None, id_viaje=None):
        super().__init__()
        
        self.pasajeros_info = pasajeros_info or []
        self.id_viaje = id_viaje
        self.indice_actual = 0
        self.datos_viaje = {}
        self.precio_base = 250.0
        
        # Diccionario para guardar diseños por pasajero (MEJORADO con logos)
        self.disenos_pasajeros = {}
        for i in range(len(self.pasajeros_info)):
            self.disenos_pasajeros[i] = {
                'primario': '#0074B7',
                'secundario': '#FFFFFF',
                'texto': '#000000',
                'acento': '#E86A1E',
                'logo_ruta': None,  # Ruta del logo personalizado
                'logo_posicion': 'superior_izquierda'
            }
        
        self.setWindowTitle("Generar Boletos - Rutas Baja Express")
        self.resize(1400, 800)
        
        # Cargar datos del viaje
        self.cargar_datos_viaje()
        
        # LAYOUT PRINCIPAL
        layout_principal = QHBoxLayout(self)
        layout_principal.setContentsMargins(0, 0, 0, 0)
        layout_principal.setSpacing(0)
        
        # ===== PANEL IZQUIERDO - Plantillas =====
        panel_izq = QFrame()
        panel_izq.setStyleSheet("background: #1a1a1a;")
        panel_izq.setFixedWidth(350)
        
        layout_izq = QVBoxLayout(panel_izq)
        layout_izq.setContentsMargins(15, 15, 15, 15)
        layout_izq.setSpacing(15)
        
        titulo_panel = QLabel("Personalización")
        titulo_panel.setFont(QFont("Arial", 20, QFont.Bold))
        titulo_panel.setStyleSheet("color: white;")
        layout_izq.addWidget(titulo_panel)
        
        # Aviso de diseño individual
        aviso_individual = QLabel("💡 Cada pasajero puede tener su propio diseño y logo")
        aviso_individual.setStyleSheet("""
            background: #2a2a2a; 
            color: #FFD700; 
            padding: 10px; 
            border-radius: 8px;
            font-size: 11px;
        """)
        aviso_individual.setWordWrap(True)
        layout_izq.addWidget(aviso_individual)
        
        lbl_pasajero = QLabel("Pasajero:")
        lbl_pasajero.setStyleSheet("color: white; font-size: 14px;")
        layout_izq.addWidget(lbl_pasajero)
        
        # Navegación de pasajeros
        nav_pasajero = QHBoxLayout()
        
        self.btn_anterior = QPushButton("◄")
        self.btn_anterior.setFixedSize(40, 40)
        self.btn_anterior.setStyleSheet("""
            QPushButton {
                background: #0074B7; color: white; border-radius: 20px;
                font-size: 18px; font-weight: bold;
            }
            QPushButton:hover { background: #005a8f; }
            QPushButton:disabled { background: #444; color: #888; }
        """)
        self.btn_anterior.clicked.connect(self.pasajero_anterior)
        
        self.lbl_contador = QLabel(f"1 / {len(self.pasajeros_info)}")
        self.lbl_contador.setStyleSheet("color: white; font-size: 16px; font-weight: bold;")
        self.lbl_contador.setAlignment(Qt.AlignCenter)
        
        self.btn_siguiente = QPushButton("►")
        self.btn_siguiente.setFixedSize(40, 40)
        self.btn_siguiente.setStyleSheet("""
            QPushButton {
                background: #0074B7; color: white; border-radius: 20px;
                font-size: 18px; font-weight: bold;
            }
            QPushButton:hover { background: #005a8f; }
            QPushButton:disabled { background: #444; color: #888; }
        """)
        self.btn_siguiente.clicked.connect(self.pasajero_siguiente)
        
        nav_pasajero.addWidget(self.btn_anterior)
        nav_pasajero.addWidget(self.lbl_contador, stretch=1)
        nav_pasajero.addWidget(self.btn_siguiente)
        layout_izq.addLayout(nav_pasajero)
        
        # Botón para copiar diseño a todos
        btn_aplicar_todos = QPushButton("📋 Aplicar este diseño a todos")
        btn_aplicar_todos.setFixedHeight(40)
        btn_aplicar_todos.setStyleSheet("""
            QPushButton {
                background: #2a2a2a; color: #FFD700; border: 2px solid #FFD700;
                border-radius: 8px; font-size: 12px; font-weight: bold;
            }
            QPushButton:hover { background: #3a3a3a; }
        """)
        btn_aplicar_todos.clicked.connect(self.aplicar_diseno_a_todos)
        layout_izq.addWidget(btn_aplicar_todos)
        
        # Scroll area para plantillas y opciones
        scroll_plantillas = QScrollArea()
        scroll_plantillas.setWidgetResizable(True)
        scroll_plantillas.setStyleSheet("""
            QScrollArea { border: none; background: transparent; }
            QScrollBar:vertical { background: #2a2a2a; width: 10px; border-radius: 5px; }
            QScrollBar::handle:vertical { background: #0074B7; border-radius: 5px; }
        """)
        
        contenedor_plantillas = QWidget()
        layout_plantillas = QVBoxLayout(contenedor_plantillas)
        layout_plantillas.setSpacing(12)
        
        # ===== SECCIÓN DE LOGO =====
        lbl_logo = QLabel("🖼️ Logo/Imagen")
        lbl_logo.setStyleSheet("color: white; font-size: 16px; font-weight: bold;")
        layout_plantillas.addWidget(lbl_logo)
        
        # Botones de gestión de logo
        btn_cargar_logo = QPushButton("📁 Cargar Logo")
        btn_cargar_logo.setFixedHeight(40)
        btn_cargar_logo.setStyleSheet("""
            QPushButton {
                background: #4CAF50; color: white; border-radius: 6px;
                font-size: 13px; font-weight: bold;
            }
            QPushButton:hover { background: #45a049; }
        """)
        btn_cargar_logo.clicked.connect(self.cargar_logo)
        layout_plantillas.addWidget(btn_cargar_logo)
        
        btn_eliminar_logo = QPushButton("🗑️ Eliminar Logo")
        btn_eliminar_logo.setFixedHeight(40)
        btn_eliminar_logo.setStyleSheet("""
            QPushButton {
                background: #f44336; color: white; border-radius: 6px;
                font-size: 13px; font-weight: bold;
            }
            QPushButton:hover { background: #da190b; }
        """)
        btn_eliminar_logo.clicked.connect(self.eliminar_logo)
        layout_plantillas.addWidget(btn_eliminar_logo)
        
        # Selector de posición del logo
        lbl_pos_logo = QLabel("Posición del logo:")
        lbl_pos_logo.setStyleSheet("color: white; font-size: 12px; margin-top: 10px;")
        layout_plantillas.addWidget(lbl_pos_logo)
        
        self.grupo_posicion_logo = QButtonGroup()
        
        posiciones = [
            ("Superior Izquierda", "superior_izquierda"),
            ("Superior Derecha", "superior_derecha"),
            ("Centro", "centro")
        ]
        
        for i, (nombre, valor) in enumerate(posiciones):
            btn_pos = QRadioButton(nombre)
            btn_pos.setStyleSheet("""
                QRadioButton {
                    color: white; font-size: 12px; padding: 5px;
                }
                QRadioButton::indicator {
                    width: 15px; height: 15px;
                }
            """)
            btn_pos.clicked.connect(lambda checked, v=valor: self.cambiar_posicion_logo(v))
            self.grupo_posicion_logo.addButton(btn_pos, i)
            layout_plantillas.addWidget(btn_pos)
        
        self.grupo_posicion_logo.button(0).setChecked(True)
        
        layout_plantillas.addSpacing(20)
        
        # ===== PLANTILLAS DE COLOR =====
        lbl_plantillas = QLabel("🎨 Plantillas de Color")
        lbl_plantillas.setStyleSheet("color: white; font-size: 16px; font-weight: bold;")
        layout_plantillas.addWidget(lbl_plantillas)
        
        self.grupo_plantillas = QButtonGroup()
        
        plantillas = [
            ("Clásico Azul", "#0074B7", "#FFFFFF", "#000000", "#E86A1E"),
            ("Nocturno", "#1a1a1a", "#FFFFFF", "#FFFFFF", "#FFD700"),
            ("Sunset", "#FF6B35", "#FFF8E7", "#2C1810", "#FFD23F"),
            ("Ocean", "#006BA6", "#E8F4F8", "#0A2463", "#1B998B"),
            ("Forest", "#2D6A4F", "#E8F5E9", "#081C15", "#95D5B2"),
            ("Royal", "#4A148C", "#F3E5F5", "#FFFFFF", "#E040FB"),
        ]
        
        for i, (nombre, primario, secundario, texto, acento) in enumerate(plantillas):
            plantilla_btn = self.crear_boton_plantilla(nombre, primario, secundario, texto, acento)
            self.grupo_plantillas.addButton(plantilla_btn, i)
            layout_plantillas.addWidget(plantilla_btn)
        
        self.grupo_plantillas.button(0).setChecked(True)
        
        layout_plantillas.addSpacing(20)
        
        # ===== COLORES PERSONALIZADOS =====
        lbl_colores = QLabel("🌈 Colores Personalizados")
        lbl_colores.setStyleSheet("color: white; font-size: 16px; font-weight: bold;")
        layout_plantillas.addWidget(lbl_colores)
        
        self.colores_custom = {}
        colores_config = [
            ("Color Primario", "primario"),
            ("Color Secundario", "secundario"),
            ("Color Texto", "texto"),
            ("Color Acento", "acento")
        ]
        
        for nombre, key in colores_config:
            btn_color = self.crear_selector_color(nombre, key)
            layout_plantillas.addWidget(btn_color)
        
        layout_plantillas.addStretch()
        
        scroll_plantillas.setWidget(contenedor_plantillas)
        layout_izq.addWidget(scroll_plantillas, stretch=1)
        
        # ===== PANEL CENTRAL - Vista previa =====
        panel_centro = QFrame()
        panel_centro.setStyleSheet("background: #f0f0f0;")
        
        layout_centro = QVBoxLayout(panel_centro)
        layout_centro.setAlignment(Qt.AlignCenter)
        layout_centro.setContentsMargins(20, 20, 20, 20)
        
        titulo_vista = QLabel("Vista Previa del Boleto")
        titulo_vista.setFont(QFont("Arial", 22, QFont.Bold))
        titulo_vista.setStyleSheet("color: #333;")
        titulo_vista.setAlignment(Qt.AlignCenter)
        layout_centro.addWidget(titulo_vista)
        
        layout_centro.addSpacing(20)
        
        self.ticket_canvas = TicketCanvas()
        layout_centro.addWidget(self.ticket_canvas, alignment=Qt.AlignCenter)
        
        layout_centro.addSpacing(30)
        
        # Botones de exportación
        botones_accion = QHBoxLayout()
        botones_accion.setSpacing(15)
        
        btn_exportar_png = QPushButton("📄 Exportar como PNG")
        btn_exportar_png.setFixedHeight(50)
        btn_exportar_png.setStyleSheet("""
            QPushButton {
                background: #4CAF50; color: white; border-radius: 8px;
                font-size: 16px; font-weight: bold; padding: 0 20px;
            }
            QPushButton:hover { background: #45a049; }
        """)
        btn_exportar_png.clicked.connect(lambda: self.exportar_boleto("PNG"))
        
        btn_exportar_pdf = QPushButton("📑 Exportar como PDF")
        btn_exportar_pdf.setFixedHeight(50)
        btn_exportar_pdf.setStyleSheet("""
            QPushButton {
                background: #2196F3; color: white; border-radius: 8px;
                font-size: 16px; font-weight: bold; padding: 0 20px;
            }
            QPushButton:hover { background: #1976D2; }
        """)
        btn_exportar_pdf.clicked.connect(lambda: self.exportar_boleto("PDF"))
        
        botones_accion.addWidget(btn_exportar_png)
        botones_accion.addWidget(btn_exportar_pdf)
        
        layout_centro.addLayout(botones_accion)
        
        # ===== PANEL DERECHO - Opciones =====
        panel_der = QFrame()
        panel_der.setStyleSheet("background: white; border-left: 2px solid #ccc;")
        panel_der.setFixedWidth(300)
        
        layout_der = QVBoxLayout(panel_der)
        layout_der.setContentsMargins(20, 20, 20, 20)
        layout_der.setSpacing(20)
        
        titulo_opciones = QLabel("Opciones de Exportación")
        titulo_opciones.setFont(QFont("Arial", 18, QFont.Bold))
        titulo_opciones.setStyleSheet("color: #333;")
        layout_der.addWidget(titulo_opciones)
        
        btn_exportar_todos = QPushButton("📦 Exportar Todos los Boletos")
        btn_exportar_todos.setFixedHeight(60)
        btn_exportar_todos.setStyleSheet("""
            QPushButton {
                background: #FF9800; color: white; border-radius: 12px;
                font-size: 15px; font-weight: bold;
            }
            QPushButton:hover { background: #F57C00; }
        """)
        btn_exportar_todos.clicked.connect(self.exportar_todos)
        layout_der.addWidget(btn_exportar_todos)
        
        # Panel de información del viaje
        frame_info = QFrame()
        frame_info.setStyleSheet("background: #E3F2FD; border-radius: 10px; padding: 15px;")
        layout_info = QVBoxLayout(frame_info)
        
        self.lbl_info_viaje = QLabel()
        self.lbl_info_viaje.setStyleSheet("color: #1565C0; font-size: 13px;")
        self.lbl_info_viaje.setWordWrap(True)
        layout_info.addWidget(self.lbl_info_viaje)
        
        layout_der.addWidget(frame_info)
        
        # Panel de información del pasajero
        frame_pasajero = QFrame()
        frame_pasajero.setStyleSheet("background: #FFF3E0; border-radius: 10px; padding: 15px;")
        layout_pax = QVBoxLayout(frame_pasajero)
        
        self.lbl_info_pasajero = QLabel()
        self.lbl_info_pasajero.setStyleSheet("color: #E65100; font-size: 13px;")
        self.lbl_info_pasajero.setWordWrap(True)
        layout_pax.addWidget(self.lbl_info_pasajero)
        
        layout_der.addWidget(frame_pasajero)
        
        layout_der.addStretch()
        
        btn_cerrar = QPushButton("Cerrar")
        btn_cerrar.setFixedHeight(45)
        btn_cerrar.setStyleSheet("""
            QPushButton {
                background: #f44336; color: white; border-radius: 8px;
                font-size: 15px; font-weight: bold;
            }
            QPushButton:hover { background: #da190b; }
        """)
        btn_cerrar.clicked.connect(self.close)
        layout_der.addWidget(btn_cerrar)
        
        # AGREGAR PANELES AL LAYOUT PRINCIPAL
        layout_principal.addWidget(panel_izq)
        layout_principal.addWidget(panel_centro, stretch=1)
        layout_principal.addWidget(panel_der)
        
        # Actualizar panel de info
        self.actualizar_info_viaje_panel()
        
        # Inicializar vista
        self.actualizar_vista_boleto()
        self.actualizar_botones_navegacion()
# ===== MÉTODOS DE GESTIÓN DE LOGOS =====
    
    def cargar_logo(self):
        """Carga un logo/imagen para el boleto actual"""
        archivo, _ = QFileDialog.getOpenFileName(
            self,
            "Seleccionar Logo/Imagen",
            "",
            "Imágenes (*.png *.jpg *.jpeg *.bmp *.svg)"
        )
        
        if archivo:
            # Intentar cargar en el canvas
            if self.ticket_canvas.set_logo(archivo):
                # Guardar ruta en el diseño del pasajero actual
                self.disenos_pasajeros[self.indice_actual]['logo_ruta'] = archivo
                QMessageBox.information(
                    self,
                    "Éxito",
                    "Logo cargado correctamente"
                )
            else:
                QMessageBox.warning(
                    self,
                    "Error",
                    "No se pudo cargar la imagen.\nVerifica que sea un archivo válido."
                )
    
    def eliminar_logo(self):
        """Elimina el logo del boleto actual"""
        self.ticket_canvas.eliminar_logo()
        self.disenos_pasajeros[self.indice_actual]['logo_ruta'] = None
        QMessageBox.information(
            self,
            "Éxito",
            "Logo eliminado"
        )
    
    def cambiar_posicion_logo(self, posicion):
        """Cambia la posición del logo"""
        self.ticket_canvas.set_posicion_logo(posicion)
        self.disenos_pasajeros[self.indice_actual]['logo_posicion'] = posicion
    
    # ===== MÉTODOS DE PLANTILLAS =====
    
    def crear_boton_plantilla(self, nombre, primario, secundario, texto, acento):
        """Crea un botón de plantilla"""
        btn = QRadioButton()
        btn.setFixedHeight(70)
        btn.setStyleSheet(f"""
            QRadioButton {{
                background: #2a2a2a; border-radius: 8px; padding: 10px;
                color: white; font-size: 14px;
            }}
            QRadioButton:hover {{ background: #3a3a3a; }}
            QRadioButton:checked {{ background: {primario}; border: 3px solid {acento}; }}
            QRadioButton::indicator {{
                width: 20px; height: 20px; border-radius: 10px;
                border: 2px solid #666; background: #1a1a1a;
            }}
            QRadioButton::indicator:checked {{ background: {acento}; border: 2px solid white; }}
        """)
        
        btn.setText(f"  {nombre}")
        btn.clicked.connect(lambda: self.aplicar_plantilla(primario, secundario, texto, acento))
        return btn
    
    def crear_selector_color(self, nombre, key):
        """Crea un selector de color"""
        container = QFrame()
        container.setStyleSheet("background: #2a2a2a; border-radius: 8px; padding: 8px;")
        
        layout = QHBoxLayout(container)
        layout.setContentsMargins(10, 5, 10, 5)
        
        lbl = QLabel(nombre)
        lbl.setStyleSheet("color: white; font-size: 13px;")
        
        btn_color = QPushButton("Elegir")
        btn_color.setFixedSize(70, 30)
        btn_color.setStyleSheet("""
            QPushButton {
                background: #0074B7; color: white; border-radius: 5px; font-size: 12px;
            }
            QPushButton:hover { background: #005a8f; }
        """)
        btn_color.clicked.connect(lambda: self.elegir_color(key))
        
        self.colores_custom[key] = "#0074B7"
        
        layout.addWidget(lbl)
        layout.addStretch()
        layout.addWidget(btn_color)
        
        return container
    
    def elegir_color(self, key):
        """Abre selector de color"""
        color = QColorDialog.getColor()
        if color.isValid():
            self.colores_custom[key] = color.name()
            self.aplicar_colores_custom()
    
    def aplicar_plantilla(self, primario, secundario, texto, acento):
        """Aplica plantilla predefinida al pasajero actual"""
        self.disenos_pasajeros[self.indice_actual].update({
            'primario': primario,
            'secundario': secundario,
            'texto': texto,
            'acento': acento
        })
        
        self.ticket_canvas.set_colores(primario, secundario, texto, acento)
    
    def aplicar_colores_custom(self):
        """Aplica colores personalizados al pasajero actual"""
        if len(self.colores_custom) == 4:
            self.disenos_pasajeros[self.indice_actual].update({
                'primario': self.colores_custom['primario'],
                'secundario': self.colores_custom['secundario'],
                'texto': self.colores_custom['texto'],
                'acento': self.colores_custom['acento']
            })
            
            self.ticket_canvas.set_colores(
                self.colores_custom['primario'],
                self.colores_custom['secundario'],
                self.colores_custom['texto'],
                self.colores_custom['acento']
            )
    
    def aplicar_diseno_a_todos(self):
        """Aplica el diseño actual a todos los pasajeros"""
        respuesta = QMessageBox.question(
            self,
            "Confirmar",
            "¿Deseas aplicar este diseño (colores y logo) a todos los boletos?",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if respuesta == QMessageBox.Yes:
            diseno_actual = self.disenos_pasajeros[self.indice_actual]
            
            for i in range(len(self.pasajeros_info)):
                self.disenos_pasajeros[i] = diseno_actual.copy()
            
            QMessageBox.information(
                self,
                "Éxito",
                "El diseño se aplicó a todos los boletos"
            )
    
    def cargar_diseno_pasajero(self):
        """Carga el diseño guardado del pasajero actual"""
        diseno = self.disenos_pasajeros[self.indice_actual]
        
        # Aplicar colores
        self.ticket_canvas.set_colores(
            diseno['primario'],
            diseno['secundario'],
            diseno['texto'],
            diseno['acento']
        )
        
        # Aplicar logo si existe
        if diseno['logo_ruta']:
            self.ticket_canvas.set_logo(diseno['logo_ruta'])
            self.ticket_canvas.set_posicion_logo(diseno['logo_posicion'])
        else:
            self.ticket_canvas.eliminar_logo()
def cargar_datos_viaje(self):
        """Carga los datos del viaje desde la BD"""
        if not self.id_viaje:
            return
        
        try:
            conn = crear_conexion()
            if not conn:
                return
            
            cursor = conn.cursor(dictionary=True)
            
            query = """
                SELECT 
                    v.numero, 
                    v.fecHoraSalida, 
                    v.fecHoraEntrada,
                    r.precio,
                    t_origen.nombre AS terminal_origen,
                    t_destino.nombre AS terminal_destino,
                    c_origen.nombre AS ciudad_origen,
                    c_destino.nombre AS ciudad_destino
                FROM viaje v
                INNER JOIN ruta r ON v.ruta = r.codigo
                INNER JOIN terminal t_origen ON r.origen = t_origen.numero
                INNER JOIN terminal t_destino ON r.destino = t_destino.numero
                INNER JOIN ciudad c_origen ON t_origen.ciudad = c_origen.clave
                INNER JOIN ciudad c_destino ON t_destino.ciudad = c_destino.clave
                WHERE v.numero = %s
            """
            
            cursor.execute(query, (self.id_viaje,))
            viaje = cursor.fetchone()
            
            if viaje:
                self.precio_base = float(viaje['precio'])
                
                fecha_salida = viaje['fecHoraSalida']
                if isinstance(fecha_salida, str):
                    fecha_salida = datetime.strptime(fecha_salida, '%Y-%m-%d %H:%M:%S')
                
                self.datos_viaje = {
                    'origen': viaje['ciudad_origen'],
                    'destino': viaje['ciudad_destino'],
                    'fecha_salida': fecha_salida.strftime('%d/%m/%Y %H:%M'),
                    'precio': self.precio_base,
                    'terminal_origen': viaje['terminal_origen'],
                    'terminal_destino': viaje['terminal_destino']
                }
            
            cursor.close()
            conn.close()
            
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Error al cargar datos del viaje:\n{e}")
    
    def actualizar_info_viaje_panel(self):
        """Actualiza el panel de información del viaje"""
        if not self.datos_viaje:
            return
        
        self.lbl_info_viaje.setText(
            f"<b>Viaje #{self.id_viaje}</b><br>"
            f"Ruta: {self.datos_viaje['origen']} → {self.datos_viaje['destino']}<br>"
            f"Salida: {self.datos_viaje['fecha_salida']}<br>"
            f"Precio base: ${self.precio_base:.2f}"
        )
    
    def actualizar_vista_boleto(self):
        """Actualiza el canvas con los datos del pasajero actual"""
        if not self.pasajeros_info:
            return
        
        try:
            info = self.pasajeros_info[self.indice_actual]
            
            conn = crear_conexion()
            if not conn:
                return
            
            cursor = conn.cursor(dictionary=True)
            
            query_pax = "SELECT paNombre, paPrimerApell, paSegundoApell FROM pasajero WHERE num = %s"
            cursor.execute(query_pax, (info['pasajero_id'],))
            pax = cursor.fetchone()
            
            query_tipo = "SELECT descripcion, descuento FROM tipo_pasajero WHERE num = %s"
            cursor.execute(query_tipo, (info['tipo_pasajero'],))
            tipo = cursor.fetchone()
            
            cursor.close()
            conn.close()
            
            if pax and tipo:
                nombre_completo = f"{pax['paNombre']} {pax['paPrimerApell']}"
                if pax['paSegundoApell']:
                    nombre_completo += f" {pax['paSegundoApell']}"
                
                numero_boleto = f"{self.id_viaje}{info['asiento_id']:03d}{info['pasajero_id']:04d}"
                
                descuento = tipo['descuento']
                precio_final = self.precio_base * (1 - descuento / 100.0)
                
                datos_boleto = {
                    'numero_boleto': numero_boleto,
                    'origen': self.datos_viaje.get('origen', ''),
                    'destino': self.datos_viaje.get('destino', ''),
                    'fecha_salida': self.datos_viaje.get('fecha_salida', ''),
                    'asiento': str(info['asiento_id']),
                    'pasajero': nombre_completo,
                    'precio': f"${precio_final:.2f}",
                    'tipo_pasajero': tipo['descripcion']
                }
                
                self.ticket_canvas.set_datos(datos_boleto)
                self.cargar_diseno_pasajero()
                
                self.lbl_info_pasajero.setText(
                    f"<b>{nombre_completo}</b><br>"
                    f"Asiento: #{info['asiento_id']}<br>"
                    f"Tipo: {tipo['descripcion']} (-{descuento}%)<br>"
                    f"Precio: ${precio_final:.2f}"
                )
                
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Error al actualizar vista:\n{e}")
    
    def pasajero_anterior(self):
        """Navega al pasajero anterior"""
        if self.indice_actual > 0:
            self.indice_actual -= 1
            self.actualizar_vista_boleto()
            self.actualizar_botones_navegacion()
    def pasajero_siguiente(self):
    """Navega al siguiente pasajero"""
    if self.indice_actual < len(self.pasajeros_info) - 1:
        self.indice_actual += 1
        self.actualizar_vista_boleto()
        self.actualizar_botones_navegacion()

    def actualizar_botones_navegacion(self):
        """Actualiza el estado de los botones de navegación"""
        self.btn_anterior.setEnabled(self.indice_actual > 0)
        self.btn_siguiente.setEnabled(self.indice_actual < len(self.pasajeros_info) - 1)
        self.lbl_contador.setText(f"{self.indice_actual + 1} / {len(self.pasajeros_info)}")

---

# 🔧 PARTE 5: Métodos de Exportación (PNG y PDF)
```python
    def exportar_boleto(self, formato):
        """Exporta el boleto actual en formato PNG o PDF con su diseño"""
        if formato == "PNG":
            archivo, _ = QFileDialog.getSaveFileName(
                self, "Guardar boleto", 
                f"Boleto_{self.indice_actual+1}.png",
                "PNG (*.png)"
            )
            if archivo:
                self.cargar_diseno_pasajero()
                
                image = self.ticket_canvas.exportar_imagen()
                if image.save(archivo):
                    QMessageBox.information(self, "Éxito", f"Boleto guardado en:\n{archivo}")
                else:
                    QMessageBox.critical(self, "Error", "No se pudo guardar el archivo")
        
        elif formato == "PDF":
            archivo, _ = QFileDialog.getSaveFileName(
                self, "Guardar boleto", 
                f"Boleto_{self.indice_actual+1}.pdf",
                "PDF (*.pdf)"
            )
            if archivo:
                self.cargar_diseno_pasajero()
                
                printer = QPrinter(QPrinter.HighResolution)
                printer.setOutputFormat(QPrinter.PdfFormat)
                printer.setOutputFileName(archivo)
                printer.setPageSize(QPrinter.A4)
                
                painter = QPainter(printer)
                scale_x = printer.pageRect().width() / self.ticket_canvas.width()
                scale_y = printer.pageRect().height() / self.ticket_canvas.height()
                scale = min(scale_x, scale_y) * 0.8
                
                painter.scale(scale, scale)
                self.ticket_canvas.render(painter, QPoint(0, 0))
                painter.end()
                
                QMessageBox.information(self, "Éxito", f"Boleto guardado en:\n{archivo}")
    
    def exportar_todos(self):
        """Exporta todos los boletos con sus diseños individuales"""
        import os
        
        carpeta = QFileDialog.getExistingDirectory(self, "Seleccionar carpeta de destino")
        if not carpeta:
            return
        
        indice_original = self.indice_actual
        
        try:
            for i in range(len(self.pasajeros_info)):
                self.indice_actual = i
                self.actualizar_vista_boleto()
                self.cargar_diseno_pasajero()
                
                info = self.pasajeros_info[i]
                conn = crear_conexion()
                if conn:
                    cursor = conn.cursor(dictionary=True)
                    cursor.execute(
                        "SELECT paNombre, paPrimerApell FROM pasajero WHERE num = %s",
                        (info['pasajero_id'],)
                    )
                    pax = cursor.fetchone()
                    cursor.close()
                    conn.close()
                    
                    if pax:
                        nombre_archivo = f"{pax['paNombre']}_{pax['paPrimerApell']}_Asiento{info['asiento_id']}"
                    else:
                        nombre_archivo = f"Boleto_{i+1}"
                else:
                    nombre_archivo = f"Boleto_{i+1}"
                
                # Exportar PNG
                archivo_png = os.path.join(carpeta, f"{nombre_archivo}.png")
                image = self.ticket_canvas.exportar_imagen()
                image.save(archivo_png)
                
                # Exportar PDF
                archivo_pdf = os.path.join(carpeta, f"{nombre_archivo}.pdf")
                printer = QPrinter(QPrinter.HighResolution)
                printer.setOutputFormat(QPrinter.PdfFormat)
                printer.setOutputFileName(archivo_pdf)
                printer.setPageSize(QPrinter.A4)
                
                painter = QPainter(printer)
                scale = min(
                    printer.pageRect().width() / self.ticket_canvas.width(),
                    printer.pageRect().height() / self.ticket_canvas.height()
                ) * 0.8
                painter.scale(scale, scale)
                self.ticket_canvas.render(painter, QPoint(0, 0))
                painter.end()
            
            self.indice_actual = indice_original
            self.actualizar_vista_boleto()
            self.actualizar_botones_navegacion()
            
            QMessageBox.information(
                self, "Éxito", 
                f"Se exportaron {len(self.pasajeros_info)} boletos en:\n{carpeta}"
            )
            
        except Exception as e:
            self.indice_actual = indice_original
            self.actualizar_vista_boleto()
            self.actualizar_botones_navegacion()
            QMessageBox.critical(self, "Error", f"Error al exportar boletos:\n{e}")